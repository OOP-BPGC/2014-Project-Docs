package events.eventutils;

public class Constants {

	public static final Long GOLD_EVENT_SCORE = 500L;
	public static final Long SILVER_EVENT_SCORE = 300L;
	public static final Long BRONZE_EVENT_SCORE = 200L;
	public static final Long DISQUALIFIED_EVENT_SCORE = 0L;
	public static final Long BETTED_EVENT_SCORE = 200L;
	
}
