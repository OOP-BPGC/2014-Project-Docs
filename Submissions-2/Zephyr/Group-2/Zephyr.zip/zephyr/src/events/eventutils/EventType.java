package events.eventutils;

public enum EventType {
	GOLD,
	SILVER,
	BRONZE
}
