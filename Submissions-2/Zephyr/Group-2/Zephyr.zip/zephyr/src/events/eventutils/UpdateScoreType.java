package events.eventutils;

public enum UpdateScoreType {
	ADD,
	SUBTRACT,
}
