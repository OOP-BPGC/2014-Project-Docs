package departments;

public class Dopy extends Department{

	public void budget() {
		// TODO Auto-generated method stub
		
	}
	
	public void coverEvent(){
		
	}
	
	public void releasePics(){
		
	}

}
