package departments;

public class Dosm extends Department{

	public void budget() {
		// TODO Auto-generated method stub
		
	}

	public int getStalls(){
		return 0;
	}
	
	public int getSponsors(){
		return 0;
	}
	
	public void takePayment(){
		
	}
}
