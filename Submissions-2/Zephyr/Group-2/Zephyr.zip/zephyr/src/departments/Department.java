package departments;

public abstract class Department {

	public abstract void budget();
	
}
