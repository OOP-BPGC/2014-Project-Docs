package departments;

public class ArtsNDeco extends Department {

	public void budget() {
		// TODO Auto-generated method stub

	}

	public void decorate(){
		
	}
}
