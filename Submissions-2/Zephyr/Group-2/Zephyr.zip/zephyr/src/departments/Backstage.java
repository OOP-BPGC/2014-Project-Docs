package departments;

public class Backstage extends Department {

	public void budget() {
		// TODO Auto-generated method stub

	}
	
	public void setUp(){
		
	}
	
	public void manageEvent(){
		
	}

}
