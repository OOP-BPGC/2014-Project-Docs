package participatingbody;

public class Administration {

	public void grantPermissions(){
		
	}
	
	public void grantReimbursements(){
		
	}
}
