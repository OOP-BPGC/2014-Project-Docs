package participatingbody.participants;

import participatingbody.Student;

public class HostelRep extends Student{

	public HostelRep(String name, String hostel, String iD, boolean attends) {
		super(name, hostel, iD, attends);
	}

	public void selectParticipants(){
		
	}
	
	public void submit(){
		
	}
	
	public void distributeTees(){
		
	}
	
	public void notifyParticipants(){
		
	}
}
