package participatingbody.participants;

import participatingbody.Student;

public class Judge extends Student{

	public Judge(String name, String hostel, String iD, boolean attends) {
		super(name, hostel, iD, attends);
	}

	public void judgeEvent(){
		
	}
	
	public void declareResults(){
		
	}
	
	public void distributePrizes(){
		
	}
}
