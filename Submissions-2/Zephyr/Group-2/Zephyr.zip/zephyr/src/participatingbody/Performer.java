package participatingbody;

public class Performer {
	
	public void perform(){
		
	}
}
