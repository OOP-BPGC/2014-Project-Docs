package exceptions;

public class NotEnoughItemsException extends Exception {
	public NotEnoughItemsException(String s)
	{
		super(s);
	}
}
