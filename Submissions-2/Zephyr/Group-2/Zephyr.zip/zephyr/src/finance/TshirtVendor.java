package finance;

public class TshirtVendor {

	public void getCP(){
		
	}
	
	public void getGoodies(){
		
	}
	
	public void takePayments(){
		
	}
	
	public void supplyTshirts(){
		
	}
}
