package finance;

public class FinalizedBudget {
	
	public boolean makePayments(){
		return true;
	}
	
	public boolean getRevenue(){
		return true;
	}
	
	
}
