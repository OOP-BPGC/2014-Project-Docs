package finance;

public class PlannedBudget {

	public boolean getQuotes(){
		return true;
	}
	
	public boolean decideSP(){
		return true;
	}
	
	public boolean decideRegistrationFee(){
		return true;
	}
	
	public boolean finalizeBudget(){
		return true;
	}
	
	public boolean updateBudget(){
		return true;
	}
}
