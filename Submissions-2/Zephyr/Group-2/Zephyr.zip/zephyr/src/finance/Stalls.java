package finance;

public class Stalls {

	public boolean sellItems(){
		return true;
	}
	
	public boolean payToZaphyrControls(){
		return true;
	}
}
