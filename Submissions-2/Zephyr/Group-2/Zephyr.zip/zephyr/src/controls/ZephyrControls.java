package controls;

public abstract class ZephyrControls {
	 int accessLevel = 1;
}
