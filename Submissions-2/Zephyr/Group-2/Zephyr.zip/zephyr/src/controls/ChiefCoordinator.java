package controls;

public class ChiefCoordinator extends ZephyrControls {

	public void promote(){
		
	}
	
	public void notifyParticipantsAndJudges(){
		
	}
	
	public void assignVerticals(){
		
	}
	
	
}
