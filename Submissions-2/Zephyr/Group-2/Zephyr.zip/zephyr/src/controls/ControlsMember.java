package controls;

public class ControlsMember extends ZephyrControls {

	public void procureMaterials(){
		
	}
	
	public void carryPRDrives(){
		
	}
	
	public void putUpPosters(){
		
	}
	
	public void manageEvent(){
		
	}
}
