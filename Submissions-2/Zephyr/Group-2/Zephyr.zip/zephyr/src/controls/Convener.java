package controls;

public class Convener extends ZephyrControls {

	public boolean acquirePermissions(){
		return true;
	}
	
	public boolean bookRooms(){
		return true;
	}
	
	public boolean finalizePerformers(){
		return true;
	}
	
	public boolean manageDepartments(){
		return true;
	}
	
	
}
