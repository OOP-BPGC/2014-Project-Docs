package controls;

public class EventsHead extends ZephyrControls {

	public void assignVerticals(){
		
	}
	
	public void manageEvents(){
		
	}
	
	public void notifyParticipantsAndJudges(){
		
	}
	
	public void publishRulebook(){
		
	}
	
	public void publishEventList(){
		
	}
}
