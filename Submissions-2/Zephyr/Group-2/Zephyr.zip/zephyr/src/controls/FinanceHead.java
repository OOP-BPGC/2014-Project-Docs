package controls;

public class FinanceHead extends ZephyrControls {

	public void coordinateSponsorship(){
		
	}
	
	public void planBudget(){
		
	}
	
	public void finalizeBudget(){
		
	}
	
	public void makePayments(){
		
	}
	
	public void collectRequirements(){
		
	}
	
	public void reviewBudgets(){
		
	}
}
