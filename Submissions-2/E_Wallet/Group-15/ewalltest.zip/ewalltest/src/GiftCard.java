

public class GiftCard {
	public int GiftCardID;
	public double gift_card_amount;
	public Offer gift_card_offer;
	public double applyGiftCard(double amount){
		return 1;
	}//returns the amount after applying offer
	
}
