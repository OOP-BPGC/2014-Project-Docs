
import java.util.ArrayList;


public class User{
	protected static int privlg;
	private Bank account;
	public static int getPrivlg() {
		return privlg;
	}
	public static void setPrivlg(int privlg) {
		User.privlg = privlg;
	}
	public Login getLogin_details() {
		return login_details;
	}
	public void setLogin_details(Login login_details) {
		this.login_details = login_details;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	public ArrayList<GiftCard> getGiftCards() {
		return giftCards;
	}
	public void setGiftCards(ArrayList<GiftCard> giftCards) {
		this.giftCards = giftCards;
	}
	public ArrayList<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(ArrayList<Transaction> transactions) {
		this.transactions = transactions;
	}
	private String email;
	private int pin;
	private Login login_details;
	private Wallet wallet;
	//private double balance;
	private ArrayList<GiftCard> giftCards;
	private ArrayList<Transaction> transactions;
	ArrayList<Offer> offers;
	
	protected String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	
	
	//public void forgotPassword(){}
	//public void signUp(){}
	//public int login(){}//return 1 if login successful 0 otherwise

	public double checkBalance(){
		return wallet.getBalance();}
	
	public double addCredit(double amount){
		wallet.setBalance(this.account.getCredits(amount) + wallet.getBalance()); 
		return wallet.getBalance();
	}
	public ArrayList<Transaction> viewTransactionHistory(){
		return transactions;}
	public ArrayList<Offer> getOffers() {
		return offers;
	}
	public void setOffers(ArrayList<Offer> offers) {
		this.offers = offers;
	}
//	public double getBalance() {
//		return balance;
//	}
//	public void setBalance(double balance) {
//		this.balance = balance;
//	}
	
	
}
