import java.util.ArrayList;


public class Customer extends User{
	
	public Customer(){
		//this.privlg=0;
	}
	public ArrayList<Offer> viewOffers(){
		return this.getOffers();}
	public void moneyTransfer(Seller s,double amount){
		//transaction object created
		//transaction list of seller and customer updated
		//balance updated
		//optional applyOffer method
		//call confirmTransaction
		}//return 1 if transaction successful 0 otherwise 
	
	public void purcahseGiftCard(){}
	
	public void sendGiftCard(Customer s){}
}

