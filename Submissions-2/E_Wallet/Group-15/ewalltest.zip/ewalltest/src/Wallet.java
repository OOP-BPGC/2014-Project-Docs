

public class Wallet {
	public double balance;
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int[] getGiftcards() {
		return giftcards;
	}
	public void setGiftcards(int[] giftcards) {
		this.giftcards = giftcards;
	}
	public int[] giftcards;
	public double getBalance() {
		// TODO Auto-generated method stub
		return balance;
	}
}

