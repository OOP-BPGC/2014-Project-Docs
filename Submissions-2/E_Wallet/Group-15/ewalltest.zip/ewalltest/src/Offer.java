

public class Offer {
	private int offerID;
	private int discount;
	private Seller s;
	public void applyOffer(double amount){
		//creates new transaction object with offer as a input
		//the alters the balance
		//and update the transaction list
		//public Transaction(Customer u1,Seller u2,double amount,Offer o)
	}//returns the amount after applying offer
}

