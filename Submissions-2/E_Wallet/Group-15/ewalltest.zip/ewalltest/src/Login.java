

public class Login {
	private String username;
	private static String password;
	public  static String forgotPassword(String username, String answer){
		return password;// when input answer matches securityAns
		}
	private String securityAns;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
